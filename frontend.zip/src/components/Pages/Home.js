import React from "react";
const Home = () => {
  return (
    <div className="Home">
      <div className="lander">
        <h1>ATechno</h1>
        <p className="text-muted">A Node Base Application</p>
        <br />
      </div>
    </div>
  );
};

export default Home;
